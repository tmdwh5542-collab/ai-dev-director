# AI DEV DIRECTOR

**픽셀 스튜디오 UI:** 움직이는 도트 직원과 남녀 2D 원화 10종, 캐릭터 스타일 선택, 게임 메뉴 형태의 회사·채용·미션·보고함 화면을 제공합니다. [픽셀 UI 안내](docs/PIXEL_STUDIO_KO.md).

**PC·태블릿·휴대폰 연동:** PC를 실행 서버로 두고 같은 Wi-Fi 또는 Tailscale 사설 연결로 회사↔집에서도 제어합니다. QR·1회용 코드 등록, 기기별 해제, 모바일의 미션·회의·승인을 지원합니다. [기기 연결 안내](docs/DEVICE_LINK_KO.md).

**회사 사무실 화면:** 대표실·기획실·개발실·테스트실·품질실을 입체 사무실로 표시합니다.
현재 AI 호출과 미션 상태에 연결되며 전용 앱에서 기본으로 열립니다.
**캐릭터 회사 운영:** 대표의 이름·성별·나이를 설정하고, 필요한 직원을 직접 채용합니다. 7개 부서에 과장 포함 각 4명(총 28명)을 구성하고 사무실 배경을 선택할 수 있습니다. 실제 AI 회의·비서 보고함·중요 안건 일괄 승인을 제공합니다. [새 회사 운영 안내](docs/COMPANY_SIMULATION_KO.md).
[직원 편집 안내](docs/STAFF_TEAM_KO.md). [회사 화면 안내](docs/COMPANY_OFFICE_KO.md).

**Windows 바탕화면 바로가기 설치:** Windows 설치용 ZIP을 모두 압축 해제한 뒤 `INSTALL_DESKTOP.cmd`를 실행하세요.
사용자 전용 폴더에 Qt 전용 앱 EXE를 만들고 **AI DEV DIRECTOR v3** 바탕화면 아이콘을 연결합니다.
첫 설치에는 Windows 64비트·Python 3.10 이상·Git·인터넷이 필요합니다.
이후에는 바탕화면 아이콘으로 실행합니다. [간단 안내](START_HERE_KO.txt) · [설치·실행 상세](docs/DESKTOP_INSTALL.md).
설치용 ZIP의 배포 목록을 사용하므로 일반 Git clone에는 기존 Python 실행 방법을 사용하세요.

**Unity·Godot 게임 제작:** 전용 앱의 **앱 → 게임 프로젝트 검증 설정**에서 엔진을 지정하고
**게임 개발** 방식으로 시작합니다. [게임 제작 안내](docs/GAME_DEVELOPMENT_KO.md)를 참고하세요.

**세 개의 AI 코딩 CLI를 한 회사처럼 돌려, 목표 한 줄을 검증된 코드로 바꾸는 로컬 개발 감독관.**
A local orchestrator that runs three subscription AI CLIs (Claude Code, OpenAI Codex, Google Antigravity) as
HEAD / BUILDER / REVIEWER, and turns a one-line goal into tested, independently reviewed code — without a single
pay-per-use API call.

> 상태: 개인 운영 환경에서 매일 쓰고 있는 코드를 그대로 공개한 것입니다. 윈도우 우선, 한국어 UI.
> **macOS / Linux: 코드는 준비돼 있지만 미검증입니다** (v3.1.8, 아래 참고). 맥에서 돌려 보신 분은 이슈로 알려 주시면 고맙겠습니다.
> Status: the code we run daily, published as-is. Windows-first, Korean UI, English comments.
> **macOS / Linux: supported in code since v3.1.8 but not yet verified on a real Mac** — reports welcome.

---

## 무엇을 하나 (What it does)

**미션 센터 2차 개선판:** 콘솔 실행 후 `http://127.0.0.1:8081/missions`에서 프로젝트 선택·직접 미션 시작,
전체 기록 검색, 실행 로그·검수 지적·코드 변경 확인, 수정 지시와 재개, 결과 반영과 보고서 저장을 사용할 수 있습니다.
시작 요청은 서버에 보관해 새로고침과 응답 유실 후에도 같은 요청을 중복 실행하지 않고 상태를 조회합니다.
스테이지 상단의 **미션 센터** 링크로도 이동할 수 있습니다. 설치·기존 기록 이전·검증 방법은
[`docs/MISSION_CENTER.md`](docs/MISSION_CENTER.md)를 참고하세요.
직접 실행과 복구 동작은 [`docs/EXECUTION_CENTER.md`](docs/EXECUTION_CENTER.md)에 설명되어 있습니다.
검증기는 각 명령에 임시 Python 캐시 경로를 사용해, 빠르게 수정한 소스 대신 이전 바이트코드를 검사하는 문제도 방지합니다.

**3차 개선 — 개발 방식과 프로젝트 기억:** 자동 선택·게임 개발·기능 개발·버그 진단·테스트 중심·보안 개선·구조 개선의
7가지 방식을 선택할 수 있습니다. 선택한 지침은 미션의 다음 단계에도 유지되며, 같은 프로젝트의 테스트·검수 통과 기록을
최대 3건 참조할 수 있습니다. 문맥 탐색도 파일·폴더·항목 수를 제한합니다.
참고한 ECC 구조, 적용 범위와 사용법은 [`docs/DEVELOPMENT_WORKFLOWS.md`](docs/DEVELOPMENT_WORKFLOWS.md)에 정리했습니다.

```
   goal ──▶ HEAD (plans an ORDER) ──▶ BUILDER (proposes whole files as JSON)
                 ▲                              │
                 │                              ▼
          HEAD decision ◀── REVIEWER ◀── Verifier (build / tests in an isolated worktree)
```

- **NORMAL 파이프라인** — HEAD가 목표를 ORDER(허용 경로·파일 수·diff 상한이 명시된 작업 명세)로 만들고, BUILDER가
  파일 전체를 JSON으로 제출하면 Director가 Scope Guard로 검사한 뒤 **격리 작업본(git worktree)** 에 반영하고 테스트를
  돌립니다. REVIEWER가 독립 검토하고 HEAD가 PASS/FAIL/수정 지시를 내립니다. 원본 프로젝트는 절대 직접 수정되지 않습니다.
- **미션(Mission)** — 채팅 한 줄이 미션이 됩니다. HEAD가 마일스톤 ORDER를 하나씩 계획하고, 각 단계는 직전 PASS 작업본의
  스냅샷에서 시작하며, 실제 증거(테스트·리뷰)를 보고 다시 계획합니다. 완료된 산출물은 설정에 따라 자동 반영되되
  사람이 그 사이 고친 파일은 덮어쓰지 않습니다.
- **HEAD 프록시 자율 모드** — 결제·실계좌 주문·실제 자격증명·되돌릴 수 없는 외부 행동만 사람에게 묻고, 나머지
  마찰(빌더 JSON 깨짐, 토큰 한도, 경로 범위, 리뷰 지적, 한도 초과)은 재시도·공급자 교체·재계획으로 스스로 풉니다.
- **TRIAD 연구 모드** — 세 AI가 독립 연구 → 상호 비판 → 종합 가설 → NORMAL 파이프라인으로 실험 구현 → 세 갈래
  해석 → 연구 메모리. 설계와 구현은 `docs/V3_TRIAD_RESEARCH_PLAN.md`.
- **TRINITY 콘솔(8081)** — 세 AI의 역할·호출·토큰·현재 단계를 보여주는 무대형 대시보드, 채팅, 미션 다시보기,
  역할 교환, **작업 정지 / 시스템 중지** 버튼. `/classic`은 표 중심의 작업실 화면입니다.

## 지키는 것 (Hard rules, enforced in code)

| 규칙 | 구현 |
|---|---|
| 종량제 API 금지 — 로그인된 구독 CLI만 사용 | `core/env_utils.py` 가 모든 `*_API_KEY` 를 환경에서 제거하고 CLI를 호출 |
| 원본 프로젝트 무수정 | 모든 빌드는 `.director_worktrees/` 안의 git worktree에서만 |
| Scope Guard | ORDER의 허용 경로·보호 경로·파일 수·diff 상한을 Director가 검사, 빌더는 완화 불가 (`core/safety.py`) |
| 리뷰어 fail-closed | 리뷰 응답이 없거나 깨지면 PASS가 아니라 FAIL |
| 돈·자격증명은 사람이 | `core/autopilot.py` 의 정지 조건 — 결제, 실계좌 주문 코드(`OrderSend` 등), 계정 생성, 외부 비가역 행동 |
| 프로세스 트리 타임아웃 | 멈춘 CLI는 자식까지 함께 종료 (`core/process_runner.py`) |
| 정지는 정지 | 채팅의 "중단/멈춰/stop", 콘솔의 작업 정지 버튼 → 돌던 CLI 즉시 종료, 미션 STOPPED 고정, 재시작해도 재개 안 됨 |

## 요구 사항 (Requirements)

- Windows 10/11 (매일 쓰는 환경). **macOS / Linux는 미검증**: 프로세스 트리 종료(psutil), 작업본 폴더 열기(`open` / `xdg-open`),
  CLI 탐색(`~/.local/bin`, `/opt/homebrew/bin`, `/usr/local/bin`), 셸 런처(`start-companion.sh`)까지 코드는 갖춰져 있으나
  실제 맥에서 돌려 보지 못했습니다. 폴더 선택 창은 tkinter라 Homebrew 파이썬은 `brew install python-tk`가 필요하고,
  없으면 콘솔에 경로를 직접 입력하면 됩니다.
- Python 3.9+ 와 `pip install -r requirements.txt`
- Git
- 로그인된 CLI 중 최소 두 개: **Claude Code**(`claude`), **OpenAI Codex**(`codex`), **Google Antigravity**(`agy`).
  구독 로그인 세션을 그대로 씁니다. API 키는 필요 없고, 있어도 무시됩니다.

## 빠른 시작 (Quick start)

```bash
pip install -r requirements.txt
python -m pytest -q            # 604개 테스트, CLI 없이 스텁으로 돕니다 (약 25분)
```

2026-11-04 기준 593/596 통과, 3개 실패 (v3.1.8에서 플랫폼 분기 테스트 8개 추가, 윈도우에서 통과). 실패 3개는 알려진 드리프트입니다: 두 개는 "저장소가 아닌 폴더는 거부"를
기대하는 옛 UI 테스트인데 v3.0부터 빈 폴더도 자동 준비(greenfield)하도록 바뀌었고, 하나는 스냅샷 제외 목록 픽스처
드리프트입니다. 안전 게이트·정책·미션 테스트는 모두 통과합니다.

콘솔 켜기 (윈도우):

```powershell
.\start-companion.ps1          # http://127.0.0.1:8081  (TRINITY 무대)  ·  /classic (작업실)
.\stop-companion.ps1
```

콘솔 켜기 (macOS / Linux, 미검증):

```bash
chmod +x start-companion.sh stop-companion.sh
./start-companion.sh           # python3 companion_server.py 를 백그라운드로, PID는 data/companion.pid
./stop-companion.sh
```

Antigravity CLI(`agy`)가 그 플랫폼에 없으면 `config.yaml`에서 BUILDER를 `codex` 또는 `claude`로 바꾸면 됩니다. CLI 두 개로도 동작합니다.

CLI로 바로 한 번 돌리기:

```bash
python director.py run -p D:/work/my_project -g "src/calc.py에 add(a, b)를 만들고 테스트를 추가해"
python director.py mission -p D:/work/my_project -g "회원가입 흐름을 끝까지 구현"
python director.py do -g "로그인 버그 고쳐" --profile quick     # 미션 + 자동 반영을 한 번에
python director.py status
python director.py clean-worktrees -p D:/work/my_project --dry-run
```

## 설정 (Configuration)

`config.yaml` 한 파일입니다. 역할별 공급자(`head/builder/reviewer`), 타임아웃, 안전 상한, 검증 명령,
자율 모드(`autonomy`)와 프로필(`quick / standard / deep`), 프로젝트별 검증 명령(`projects`)을 둡니다.
프로젝트별 검증 명령을 프로젝트 안이 아니라 여기에 두는 이유는 빌더가 그것을 약화시킬 수 없게 하기 위해서입니다.

`companion.json` 은 콘솔 포트와(선택) 허용 프로젝트 목록입니다. 콘솔은 항상 `127.0.0.1` 에만 바인딩되며,
상태를 바꾸는 요청은 로컬 출처 검사와 브리지 토큰(`data/solomon-bridge.token`, 첫 실행 때 생성)을 요구합니다.

## 구조 (Layout)

```
director.py            CLI 진입점 (run / mission / do / status / resume / clean-worktrees)
companion_server.py    8081 콘솔 서버 (정적 파일 허용 목록 + /ops/* API)
dashboard_server.py    작업실(/classic)·채팅·미션 정지·상태 요약
agents/                HEAD / BUILDER / REVIEWER 어댑터 (claude, codex, antigravity, google 역할, mock)
core/                  orchestrator, mission, autopilot(정책), safety(Scope Guard), verifier, git_manager,
                       process_runner, provider_manager(장애 조치), research_*(TRIAD), usage(토큰 집계)
schemas/               ORDER / BuilderResult / ReviewResult / Decision / Provenance (pydantic)
console/               TRINITY 무대와 작업실 프런트엔드 (의존성 없는 정적 파일)
scripts/               폴더 선택 도우미, CLI 진단, 실패 run 재시도, 역할 smoke
tests/                 604 tests (스텁 CLI로 격리, 로컬 설정 파일에 의존하지 않음; 실제 CLI 통합은 -m integration_cli 로 opt-in)
docs/                  설계·마일스톤 기록
```

## 알려진 한계 (Known limits)

- 큰 변경도 "파일 전체 JSON 제안" 방식이라 CLI 출력 한도에 걸릴 수 있습니다. 한 번은 압축 재시도, 그 다음은 공급자 교체.
- 각 CLI의 구독 한도(쿼터)에 그대로 종속됩니다. 한도가 끝나면 장애 조치 순서대로 다른 CLI로 넘어갑니다.
- 리뷰어와 HEAD가 같은 공급자로 몰리면 `REDUCED_INDEPENDENCE` 표시와 함께 통과시킵니다(숨기지 않음).
- 테스트는 로컬 스텁 CLI로 돕니다. 실제 세 CLI를 끝까지 태우는 E2E는 opt-in 마커로만 돌아갑니다.
- macOS / Linux는 미검증입니다. 일부 테스트는 윈도우 드라이브 문자 경로(`C:/...`)를 전제로 해서 그 플랫폼에서는 실패할 수 있으며, 제품 동작과는 무관합니다.

## 라이선스 (License)

MIT License — `LICENSE` 파일을 보세요. 자유롭게 쓰고, 고치고, 재배포할 수 있습니다. 저작권 표시와 라이선스 문구만 남겨 주세요.

### 웹 작업실 (대화 + 웹 미리보기)

회사 사무실이나 메인 화면의 **웹 작업실**(`/web-workspace`)에서 왼쪽 AI 대화와 오른쪽 웹 미리보기를 함께 사용합니다. 기존 프로젝트·HEAD 대화·실행 계약을 공유하며 별도의 AI 계정을 추가하지 않습니다. 프로젝트를 선택한 뒤 요청을 입력하고, 실행 중인 개발 서버나 웹사이트의 전체 HTTP/HTTPS 주소를 오른쪽에 입력하세요. 개발 서버는 자동으로 실행하지 않습니다.

미리보기는 데스크톱 전체 폭·태블릿 768px·모바일 390px을 지원합니다. 대화 조회나 전송은 미리보기를 다시 로드하지 않으며 새로고침 버튼으로 직접 갱신할 수 있습니다. 내부 표시가 차단된 사이트는 새 창에서 확인하세요. 입력 초안과 마지막 주소는 해당 브라우저에 보관하며 다시 방문했을 때 외부 사이트를 자동으로 열지 않습니다. 태블릿에서 `localhost`는 태블릿 자체이므로 PC 개발 서버의 접근 가능한 주소가 필요합니다. 이번 패치는 설치 파일 배포나 외부 사이트 배포를 포함하지 않습니다.

### 웹 개발 도구·직원 도구·사무실 최적화 (2026-11-17)

웹 작업실의 **개발 서버 · 검수 · 체크포인트**에서 선택한 프로젝트의 `dev/start/serve/preview` npm 스크립트를 실행하고, 준비된 루프백 주소를 미리보기에 연결할 수 있습니다. 포트를 지정하며 프로그램이 시작한 프로세스만 중지합니다. 프로젝트 의존성 설치나 사이트 배포는 실행하지 않습니다.

- **코드 편집 / 변경 비교:** Monaco를 필요할 때만 로드합니다. UTF-8 소스 저장은 읽은 파일의 SHA-256이 일치할 때만 가능하고 저장 전 상태를 보관합니다. Monaco가 없으면 기본 텍스트 편집기를 제공합니다.
- **체크포인트 / 복구:** AI 대화 전·편집 전·서버 시작 전에 일반 소스를 보관합니다. 복구는 비교 이후 변경이 없을 때만 진행하고, 복구 직전 상태도 다시 보관합니다. 진행 중인 AI 작업·회의가 있으면 편집/복구를 거부하고, 복구 전에는 개발 서버를 중지해야 합니다. 숨김·비밀·심볼릭 링크·빌드/의존성 폴더를 제외합니다. 파일 1MB, 전체 16MB, 600개, 보관본 30개 한도이며 선택한 보관본을 삭제할 수 있습니다. 게임 대형 바이너리나 Git 전체 이력의 백업을 대신하지 않습니다.
- **Playwright 실제 검수:** 이 작업실에서 실행한 개발 서버에 한해 1440/768/390px 화면, JS·HTTP 오류, 가로 넘침과 스크린샷을 기록합니다. 선택형 JSON 단계로 click/fill을 최대 8개 지정할 수 있습니다. 다른 출처 요청을 차단하며 별도 계정 로그인이나 운영 사이트 변경은 수행하지 않습니다. 검수 성공은 지정한 범위의 실행 증거이며 전체 제품 무결성을 뜻하지 않습니다.
- **Lighthouse 실제 진단:** 성능·접근성·권장사항·SEO 점수와 개선 항목을 보관합니다. 로컬 개발 서버의 단일 측정이며 운영/실사용 성능과 구분합니다. 검수 보고서는 웹 작업실과 비서실에 표시합니다. 검수 프로세스는 최대 150초로 제한하며 시간 초과·시스템 중지 때 소유한 자식 프로세스도 정리합니다.
- **직원 도구 / MCP:** AI·스킬 설정에서 직원별 프로젝트 목록·소스 읽기·검수 보고서·공개 GitHub 조회 권한을 지정합니다. `scripts/director_mcp.py --project <절대 경로> --staff <ID>`는 표준 JSON-RPC stdio의 MCP 읽기 도구를 제공합니다. AI CLI의 MCP 설정에 등록할 값은 화면에 표시하며 계정·전역 CLI 설정을 자동으로 바꾸지 않습니다. 외부 MCP 실행 파일을 무제한 설치/실행하는 기능은 제공하지 않습니다.
- **공용 Hermes 조사:** 설정한 담당자 1명이 기존 Hermes SDK·API 등록·일일 한도·단일 실행 제한을 공유합니다. 업무가 진행 중이면 다음 요청을 거부하며 무제한 병렬 호출하지 않습니다. 기존 보고서 채택/반려와 비서실 보고를 유지합니다. 도구 등록과 실제 외부 AI 호출 성공은 구분합니다.
- **최적화:** 현재 방만 유지하는 구조에 화면 밖 캐릭터 그리기 생략, 화면 밖 사무실/숨김 탭 애니메이션 정지, 약 30회/초 이동 갱신 제한을 추가했습니다. 웹 대화는 숨김 탭에서 조회를 중지하고, 같은 보고서는 DOM을 다시 만들지 않습니다. Monaco/PixiJS는 선택할 때만 로드합니다.
- **선택형 PixiJS:** 사무실의 ‘그리기 → 캐릭터 GPU’로 고해상도 2D 인물을 WebGL로 표시합니다. 입력·접근성·이름표·가구는 기존 SVG 구조를 유지하며 기존 절전 SVG가 기본입니다. 변경이 있을 때만 GPU를 그리며 GPU 오류는 SVG로 되돌립니다. PixiJS의 CSP 지원 모듈을 사용하므로 unsafe-eval 허용을 추가하지 않습니다. GPU 사용이 모든 기기에서 더 빠르다고 보장하지 않습니다.

선택형 Node 도구 설치는 PC에서 `python scripts/setup_web_tools.py`를 실행합니다. Node.js 22.19 이상/npm과 Chromium 다운로드 공간이 필요합니다. 고정 버전은 `tools/web/package-lock.json`에 기록하며 프로젝트의 package.json은 수정하지 않습니다. 설치된 `node_modules`는 배포 ZIP에 포함하지 않고, Monaco/PixiJS 브라우저 자산과 원본 라이선스는 `console/vendor/`에 보관합니다. 라이브러리 라이선스: Playwright·Lighthouse Apache-2.0, Monaco·PixiJS MIT. 외부 AI API 이용료와 설치/모델 계정 등록은 별개입니다.

PC에서 서버·편집·복구·직원 도구를 제어합니다. 페어링 기기는 등록된 프로젝트의 서버 상태와 보고서를 읽을 수 있으며 새로운 쓰기 권한을 자동 부여하지 않습니다. PC 루프백 미리보기 주소는 태블릿의 로컬 주소로 사용할 수 없습니다. 이번 패치는 설치 ZIP·운영 배포·외부 AI 실결제를 수행하지 않았습니다.

### 순서별 설치·연결 점검 (2026-11-19)

회사 사무실 또는 AI·스킬 설정에서 **설치·연결 점검**(`/setup`)을 엽니다. PC 전용 화면이며 다음 순서로 준비 상태를 구분합니다.

1. Node.js 실제 버전과 npm 존재 여부를 확인합니다. Node.js 22.19 이상이 아니면 공식 다운로드를 안내합니다. OS 설치·관리자 권한 요청은 자동 실행하지 않습니다.
2. 고정 버전 의존성과 Chromium 실행 파일을 확인합니다. 설치·복구 버튼은 기존 `scripts/setup_web_tools.py`만 실행하며 임의 명령을 받지 않습니다. 진행 로그·취소·20분 제한·중복 실행 방지를 지원하고, 종료 코드와 실제 준비 상태를 함께 확인합니다. API 키·토큰 환경변수를 설치 프로세스에 전달하지 않으며 npm 사용자 설정은 별도의 빈 파일로 분리합니다. 앱을 중지하면 소유한 설치 프로세스도 종료합니다.
3. 등록된 프로젝트와 직원을 선택해 실제 MCP stdio 초기화와 tools/list를 검사합니다. 결과는 팀·도구 권한이 바뀌면 무효화됩니다. Codex TOML, Claude Code/Gemini CLI JSON 등록 정보를 각각 표시·복사하며 사용자 계정의 기존 설정은 읽거나 덮어쓰지 않습니다. MCP 브리지 검사 완료를 클라이언트 등록이나 AI 로그인 완료로 표시하지 않습니다.
4. 선택형 Hermes의 SDK 점검·키 존재·모델 지정·활성화 상태를 구분하고 기존 설정 화면으로 연결합니다. API 인증·할당량·유료 호출 성공은 확인하지 않으며 API 키 값은 화면이나 채팅에 입력하지 않습니다.

점검은 실행 중인 PC에만 적용됩니다. 이 작업 환경에서의 점검·패치가 사용자의 별도 PC에 설치된 것을 의미하지 않습니다. 설치 결과 기록은 로컬 `setup_assistant.json`에 보관하며 실제 키 값은 포함하지 않습니다. 이번 검증은 실제 MCP 연결·브라우저 화면 검사와 모의 설치 프로세스 검사입니다. 실제 사용자 Windows 설치·계정 로그인·유료 API 호출·설치 ZIP 배포는 수행하지 않았습니다.

### 설치 후 첫 실행·배포 전 사전 검사 (2026-11-19)

성공한 Windows 설치가 새 안내 버전의 첫 실행 표시를 남기면 전용 앱은 `/setup`으로 시작합니다. 사용자는 안내 확인 후 사무실로 이동할 수 있으며 이 동작은 Node 설치나 MCP/API 인증을 완료로 바꾸지 않습니다. 같은 안내 버전에서 이미 확인한 상태는 재설치해도 유지합니다. 앱 메뉴에서 설치·연결 점검과 웹 작업실을 다시 열 수 있습니다.

전용 앱의 웹 작업실에서 HTTP/HTTPS 미리보기 프레임을 허용하도록 보정했습니다. 다른 화면이나 앱 전체 창의 HTTP 외부 이동, 파일/스크립트 주소, 인증 정보가 붙은 미리보기 주소는 계속 제한합니다. 별도 포트 개발 서버의 실제 표시와 점검 → 안내 확인 → 사무실 이동을 QtWebEngine에서 검증했습니다. 이 검증은 Linux Qt 실행이며 Windows 설치 프로그램 전체 실행과 구분합니다.

`python scripts/build_desktop_package.py --check`는 ZIP을 만들지 않고 다음 배포의 필수 파일·고정 버전 도구 목록·라이선스 포함 여부를 검사합니다. 최신 설치 형식은 필요한 설정 화면이나 도구 파일이 누락되면 복사 전에 거부합니다. 사용자 운영 기록·인증 파일·실행 환경·node_modules·검수 산출물은 배포 대상에서 제외합니다. 실제 ZIP 생성·다운로드 제공은 요청 시 별도로 진행합니다.

### 프로젝트 작업 규칙: 네 가지 원칙 (2026-11-19)

AI·스킬 설정의 **프로젝트 작업 규칙**에서 검증 수준을 간단·균형(기본)·엄격으로 선택합니다. 모든 수준에서 중요한 기능은 실행 근거를 요구하며 간단 수준도 기존 권한·독립 검수·회귀 검사를 생략하지 않습니다. 문서·단순 색상/문구 변경에는 일괄 실행 검사나 대표 승인을 추가하지 않습니다.

- 정보 확인: 기존 파일 탐색은 이름만 읽는 기존 계약을 유지합니다. 실제 계획 단계에서만 루트 AGENTS.md·CLAUDE.md·README, 엔진/패키지 선언과 제한된 소스 발췌를 읽어 전달합니다. 문서는 참고 자료이며 권한·예산을 확장하지 않고 기존 문서를 수정하지 않습니다. 중요한 누락 정보만 질문하고 일상적인 선택은 가정을 기록해 진행하도록 지침을 전달합니다. 모델이 실제로 모든 소스를 이해했음을 자동 보장하는 기능은 아닙니다.
- 근거 있는 판단: 계획·구현·검수 역할에 기술적 모순·성능·비용·부작용과 대안을 검토하는 지침을 전달합니다. 요청에 동의했는지 문장만으로 강제 판별하거나 모든 선택에 대표 승인을 요구하지 않습니다.
- 완료 판정: 중요 기능은 등록한 별도 실행 검증 명령을 격리 작업본에서 실행하고 범위·종료 코드·출력을 기록합니다. 기존 감독관 소유 엔진 어댑터로 실제 실행한 Godot·Unity PlayMode 검증은 재사용하며, Unity EditMode나 일반 단위 테스트를 플레이 근거로 승격하지 않습니다. 기존 빌드/테스트/독립 검수와 분리되며, 명령 미설정은 `RUNTIME_NOT_CONFIGURED`로 완료를 보류합니다. 이는 추가 승인 요청이 아니라 검증 설정 필요 상태입니다. 실행 후 Git 대상 파일의 크기·수정 시각·목록이 달라지면 실행 근거를 만료 처리합니다. 중요한 실행 검증 실패 뒤 사소한 단계가 통과해도 미션 전체를 DONE으로 바꾸지 않습니다. 메타데이터 확인은 악의적인 변경에 대한 암호학적 보증은 아닙니다.
- 실패 참고: 테스트 실패·검수 지적·실행 검증 실패를 프로젝트별 관찰 기록으로 묶고 다음 계획과 직원 지침에 전달합니다. 같은 실행 ID는 중복 집계하지 않습니다. 기록을 검증된 근본 원인·해결법이나 추가 실행 권한으로 취급하지 않습니다. 기존 단계/재시도 예산을 유지합니다.

등록 명령은 JSON 배열이며 확인하는 동작 범위를 함께 적습니다. 코드·엔진·프로젝트에 맞는 로컬 검증 명령을 사용하고 운영 배포·다운로드·유료 API 호출·암호를 넣지 마세요. 명령이 통과해도 등록 범위 밖의 수동 플레이·실기기·외부 서비스는 미검증입니다. 실행 검증 결과와 미검증 항목은 미션 화면·상세 근거·보고서에 표시하며 관찰 기록은 비서실에도 연결합니다. 규칙/관찰 기록은 운영 백업에 포함됩니다. 이번 패치는 설치 ZIP이나 외부 사이트 배포를 만들지 않았습니다.

### 데스크톱 자동 업데이트 (2026-11-20)

GitHub 배포용 `release_channel.json`에는 공개 저장소 주소와 서명 공개키만 포함합니다. Windows 설치기는 업데이트 설정이 없는 경우에만 해당 채널을 `data/update_settings.json`에 등록합니다. 기존 설정을 유지하며 개인 서명키는 저장소 밖에 보관합니다. 배포 저장소의 게시·권한 연결 여부와 실제 Windows 검증 범위는 Release 안내를 확인하세요.

앱 메뉴의 **업데이트 확인**(`/updates`)에서 설치 버전·새 버전·변경 내용·검증 상태를 확인합니다. 배포자가 지정한 공개 GitHub 저장소(`owner/repository`)와 Ed25519 공개키를 PC에서 등록하면 시작 8초 뒤와 6시간마다 최신 정식 Release를 확인합니다. 기본 설정은 미등록이며 등록 전에는 업데이트 네트워크 요청을 하지 않습니다. 자동 확인은 켜져 있고 자동 다운로드는 선택 사항입니다. 적용은 사용자가 버튼으로 시작하며 작업 중에는 거부합니다. 태블릿·휴대폰에는 업데이트 설정·적용 권한을 부여하지 않습니다.

다운로드는 Release의 `director-update.json` 서명, 저장소, 버전, ZIP 크기·SHA-256, 배포 파일별 해시를 검사합니다. 서명 공개키는 배포자에게 별도로 확인해야 합니다. 업데이트 화면에는 비밀번호·GitHub 토큰·개인 서명키를 입력하지 않습니다. HTTPS 공개 Releases만 지원하며 사설 저장소 인증은 지원하지 않습니다. ZIP 한도는 160MB, 압축 해제 한도는 256MB입니다.

설치된 전용 데스크톱 앱에서 적용하면 별도 도우미가 등록된 앱 창과 서버의 종료를 기다리고 코드·운영 기록을 백업한 뒤 변경 파일을 교체합니다. 운영 기록 백업 한도는 512MB/20,000파일이며 초과 시 적용을 중단합니다. 포트의 다른 프로그램은 종료하지 않습니다. 새 서버를 AI 재개·예약 업무·외부 기기 접속 없이 시험 기동해 설치 식별자와 버전을 확인한 뒤 앱을 다시 엽니다. 이 시작 검사는 전체 UI·외부 AI·모든 프로젝트의 정상 동작을 보장하지 않습니다. 적용 또는 시작 검사에 실패하면 적용 직전 코드와 데이터(SQLite 포함)를 복구합니다. 복구 백업이 손상되면 앱 시작을 보류하고 `data/app_updates` 기록을 남깁니다. 중간에 종료된 적용은 다음 실행에서 복구합니다. 업데이트 완료 후 새 작업이 진행된 시점의 임의 버전 되돌리기는 제공하지 않습니다.

`config.yaml`, `companion.json`, 사용자 기록·인증 파일·별도 실행 환경은 배포 코드로 덮어쓰지 않습니다. 로컬에서 수정한 배포 코드와 충돌하면 중단합니다. **전용 실행 파일·런처·Python 의존성이 바뀌는 릴리스는 전체 설치가 필요**하다고 표시하며 자동 교체하지 않습니다. 이번 업데이트 기능을 처음 받는 기존 설치본도 전체 설치가 한 번 필요합니다. 새 코드·화면·자산 업데이트에는 이 기능을 사용할 수 있습니다. 브라우저 캐시는 설치 버전별로 분리하고 세션 저장소는 유지합니다.

배포 준비는 `release_version.py`의 버전 증가 → 배포 검사/전체 패키지 생성 → `scripts/sign_update.py`로 해당 ZIP의 메타데이터 서명 → GitHub 정식 Release에 ZIP과 `director-update.json` 게시 순서입니다. 서명 도구 인자는 `--archive`, `--repository`, `--asset-url`, `--notes-file`, `--private-key`, `--output`이며 로컬 Ed25519 PEM 개인키를 읽고 업로드는 하지 않습니다. 개인키는 배포 폴더와 Git에 넣지 않습니다. 저장소·공개키 등록과 실제 서명된 릴리스 게시가 있어야 사용자 PC가 새 버전을 받을 수 있습니다.

이번 작업은 서명·손상/경로 공격 거부, 임시 설치본의 파일/SQLite 복구, 독립 도우미 복구, 실제 로컬 서버 시작 검사, 업데이트 화면 및 Linux Qt 창 종료를 검증합니다. 실제 Windows 설치본의 다운로드·교체·재실행, 운영 GitHub Release, 외부 서비스 연결은 별도 검증이 필요합니다. 설치 ZIP 생성·게시·다운로드 배포는 하지 않았습니다.
