"""Version of this source release; publisher increments before signing a new release."""
VERSION='2026.11.24.1'
UPDATER_PROTOCOL=1
